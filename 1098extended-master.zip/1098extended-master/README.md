Current Version: 12.86.11669
=============

What is this?
=============

"Downgraded" client files converted from Assets to the old .spr/.dat format
for compatibility with old tools, like: RME, OTC, Object Builder etc
Until proper Assets loading/saving function is added to them.


Other Applications
==========

* To host your MMORPG game server, you can use [The Forgotten Server](https://github.com/otland/forgottenserver)
* To play your MMORPG game, you can use [OTClient](https://github.com/edubart/otclient)
* To map your MMORPG game, you can use [RME](https://github.com/hjnilsson/rme/releases)
